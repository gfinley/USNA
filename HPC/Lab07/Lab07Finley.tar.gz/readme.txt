THe average density remainging after 5 runs at 80% density and 50% catch rate was approx ~5% of the first forest state. The best was ~7% and worst was ~1%.

With higher densities more fires spread more quickly. Below ~50% density fires would still start but would quickly isolate themselves out and stop the spread. As wind speed picked up some forest fires did not spread as quickly as others. This is because if the fires start on the edge the map and the wind is blowing in the direction of the closest forest edge then the forest would quickly burn itself out.



./fire 2250 50 0 0 0
./fire 2250 99 0 0 0
./fire 2250 10 0 0 0
./fire 2250 50 10 0 0
./fire 2250 50 30 0 0
./fire 2250 50 30 30 0
./fire 2250 50 0 30 0

run a variety of different test cases
